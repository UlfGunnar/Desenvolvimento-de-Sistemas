<?php

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

const MAX_BASES_UPLOAD = 5;
const MAX_UPLOAD_BYTES = 2097152; // 2 MB

// Mantém o projeto funcional mesmo sem a extensão mbstring e em versões
// do PHP anteriores à introdução de array_is_list().
function textoTamanho($valor)
{
    $valor = (string) $valor;
    return function_exists('mb_strlen') ? mb_strlen($valor, 'UTF-8') : strlen($valor);
}

function textoMinusculo($valor)
{
    $valor = (string) $valor;
    return function_exists('mb_strtolower') ? mb_strtolower($valor, 'UTF-8') : strtolower($valor);
}

function ehLista($dados)
{
    if (!is_array($dados)) {
        return false;
    }

    $indice = 0;
    foreach ($dados as $chave => $_) {
        if ($chave !== $indice++) {
            return false;
        }
    }

    return true;
}

$arquivoPadrao = __DIR__ . '/dados.json';
$diretorioBases = __DIR__ . '/bases';

if (!is_dir($diretorioBases) && !mkdir($diretorioBases, 0775, true) && !is_dir($diretorioBases)) {
    erro('Não foi possível criar a pasta de bases. Verifique as permissões de escrita do servidor.', 500);
}

function responder($dados, $status = 200)
{
    http_response_code($status);
    echo json_encode($dados, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function erro($message, $status = 400, $errors = null)
{
    $payload = [
        'error' => true,
        'status' => $status,
        'message' => $message
    ];

    if ($errors !== null) {
        $payload['errors'] = $errors;
    }

    responder($payload, $status);
}

function erroValidacao($erros)
{
    erro('Dados inválidos', 422, $erros);
}

function listarBases($diretorioBases)
{
    $bases = [
        [
            'id' => 'dados.json',
            'nome' => 'Base padrão',
            'arquivo' => 'dados.json',
            'padrao' => true
        ]
    ];

    $arquivos = glob($diretorioBases . '/*.json') ?: [];
    sort($arquivos, SORT_NATURAL | SORT_FLAG_CASE);

    foreach ($arquivos as $arquivo) {
        $nome = basename($arquivo);
        $bases[] = [
            'id' => $nome,
            'nome' => pathinfo($nome, PATHINFO_FILENAME),
            'arquivo' => $nome,
            'padrao' => false
        ];
    }

    return $bases;
}

function caminhoBaseSelecionada($base, $arquivoPadrao, $diretorioBases)
{
    if ($base === null || $base === '' || $base === 'dados.json') {
        return $arquivoPadrao;
    }

    $nomeSeguro = basename($base);

    if ($nomeSeguro !== $base || strtolower(pathinfo($nomeSeguro, PATHINFO_EXTENSION)) !== 'json') {
        erro('Base de dados inválida.', 400);
    }

    $caminho = $diretorioBases . '/' . $nomeSeguro;

    if (!is_file($caminho)) {
        erro('Base de dados não encontrada.', 404);
    }

    return $caminho;
}

function carregarUsuarios($arquivo)
{
    if (!file_exists($arquivo)) {
        file_put_contents($arquivo, '[]');
    }

    $conteudo = file_get_contents($arquivo);
    $dados = json_decode($conteudo, true);

    if (!is_array($dados)) {
        erro('A base selecionada não contém um array JSON válido.', 500);
    }

    return $dados;
}

function salvarUsuarios($arquivo, $usuarios)
{
    $json = json_encode(array_values($usuarios), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

    if ($json === false) {
        erro('Não foi possível converter os dados para JSON.', 500);
    }

    $resultado = @file_put_contents($arquivo, $json, LOCK_EX);

    if ($resultado === false) {
        erro('Não foi possível salvar a base de dados. Verifique a permissão de escrita do arquivo e da pasta.', 500);
    }
}

function lerJson()
{
    $conteudo = file_get_contents('php://input');
    $dados = json_decode($conteudo, true);

    if ($conteudo !== '' && json_last_error() !== JSON_ERROR_NONE) {
        erro('JSON inválido', 400);
    }

    return $dados ?? [];
}

function validarUsuario($dados, $parcial = false)
{
    $erros = [];

    if (!$parcial || array_key_exists('Nickname', $dados)) {
        $Nickname = trim((string) ($dados['Nickname'] ?? ''));

        if ($Nickname === '') {
            $erros['Nickname'] = 'O Nickname é obrigatório.';
        } elseif (textoTamanho($Nickname) < 2) {
            $erros['Nickname'] = 'O Nickname deve ter pelo menos 2 caracteres.';
        } elseif (textoTamanho($Nickname) > 100) {
            $erros['Nickname'] = 'O Nickname deve ter no máximo 100 caracteres.';
        }
    }

    if (!$parcial || array_key_exists('Titulos', $dados)) {
        $Titulos = trim((string) ($dados['Titulos'] ?? ''));
    }

    if (!$parcial || array_key_exists('Rating', $dados)) {
        $Rating = $dados['Rating'] ?? null;

        if (!is_numeric($Rating) || (float) $Rating < 0) {
            $erros['Rating'] = 'O Rating deve ser maior que 0.';
        }
    }

    if (!$parcial || array_key_exists('Team', $dados)) {
        $Team = trim((string) ($dados['Team'] ?? ''));
    }

    return $erros;
}

function validarBaseImportada($dados)
{
    if (!is_array($dados) || !ehLista($dados)) {
        return ['base' => 'O JSON deve ter um array de usuários na raiz.'];
    }

    $erros = [];
    $ids = [];
    $Nicknames = [];

    foreach ($dados as $indice => $usuario) {
        if (!is_array($usuario)) {
            $erros["registro_$indice"] = 'Cada item da base deve ser um objeto JSON.';
            continue;
        }

        if (!array_key_exists('id', $usuario) || filter_var($usuario['id'], FILTER_VALIDATE_INT) === false || (int) $usuario['id'] < 1) {
            $erros["registro_$indice.id"] = 'O ID deve ser um inteiro positivo.';
        } else {
            $id = (int) $usuario['id'];
            if (isset($ids[$id])) {
                $erros["registro_$indice.id"] = 'O ID está duplicado na base.';
            }
            $ids[$id] = true;
        }

        $validacao = validarUsuario($usuario);

        foreach ($validacao as $campo => $mensagem) {
            $erros["registro_$indice.$campo"] = $mensagem;
        }

        $chave = strtolower(trim((string) ($usuario['Nickname'] ?? '')));
        if ($chave !== '') {
            if (isset($Nicknames[$Nickname])) {
                $erros["registro_$indice.email"] = 'O e-mail está duplicado na base.';
            }
            $emails[$Nickname] = true;
        }

        if (count($erros) >= 20) {
            $erros['base'] = 'A validação foi interrompida após encontrar muitos erros.';
            break;
        }
    }

    return $erros;
}

function normalizarBaseImportada($dados)
{
    return array_map(function ($usuario) {
        return [
            'id' => (int) $usuario['id'],
            'Nickname' => trim($usuario['Nickname']),
            'Titulos' => trim((string) ($usuario['Titulos'] ?? '')),
            'Rating' =>  (float) $usuario['Rating'],
            'Team' => trim((string) ($usuario['Team'] ?? ''))
        ];
    }, $dados);
}

function emailEmUso($usuarios, $Nickname, $ignorarId = null)
{
    foreach ($usuarios as $usuario) {
        if (
            isset($usuario['Nickname'], $usuario['id']) &&
            strtolower($usuario['Nickname']) === strtolower($Nickname) &&
            ($ignorarId === null || (int) $usuario['id'] !== $ignorarId)
        ) {
            return true;
        }
    }

    return false;
}

$metodo = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? null;

if ($action === 'bases') {
    if ($metodo !== 'GET') {
        erro('Método não permitido para esta ação.', 405);
    }

    $bases = listarBases($diretorioBases);

    responder([
        'max_uploads' => MAX_BASES_UPLOAD,
        'uploads_utilizados' => max(0, count($bases) - 1),
        'bases' => $bases
    ]);
}

if ($action === 'upload-base') {
    if ($metodo !== 'POST') {
        erro('Método não permitido para esta ação.', 405);
    }

    $bases = listarBases($diretorioBases);
    $uploadsUtilizados = max(0, count($bases) - 1);

    if ($uploadsUtilizados >= MAX_BASES_UPLOAD) {
        erro('O limite de 5 bases JSON anexadas foi atingido.', 409);
    }

    if (!isset($_FILES['base'])) {
        erro('Selecione um arquivo JSON para enviar.', 400);
    }

    $upload = $_FILES['base'];

    if ($upload['error'] !== UPLOAD_ERR_OK) {
        erro('Falha no upload do arquivo.', 400);
    }

    if ($upload['size'] > MAX_UPLOAD_BYTES) {
        erro('O arquivo deve ter no máximo 2 MB.', 413);
    }

    $nomeOriginal = basename($upload['name']);
    $extensao = strtolower(pathinfo($nomeOriginal, PATHINFO_EXTENSION));

    if ($extensao !== 'json') {
        erro('Apenas arquivos com extensão .json são permitidos.', 415);
    }

    $nomeBase = pathinfo($nomeOriginal, PATHINFO_FILENAME);
    $nomeSeguro = preg_replace('/[^a-zA-Z0-9_-]+/', '-', $nomeBase);
    $nomeSeguro = trim($nomeSeguro, '-_');

    if ($nomeSeguro === '') {
        $nomeSeguro = 'base';
    }

    $nomeFinal = $nomeSeguro . '.json';
    $destino = $diretorioBases . '/' . $nomeFinal;

    if (file_exists($destino)) {
        erro('Já existe uma base com esse nome. Renomeie o arquivo e tente novamente.', 409);
    }

    $conteudo = @file_get_contents($upload['tmp_name']);

    if ($conteudo === false) {
        erro('Não foi possível ler o arquivo temporário enviado.', 400);
    }

    // Remove BOM UTF-8, comum em JSONs exportados por editores/planilhas.
    if (substr($conteudo, 0, 3) === "\xEF\xBB\xBF") {
        $conteudo = substr($conteudo, 3);
    }

    $dados = json_decode($conteudo, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        erro('O arquivo enviado não contém JSON válido.', 422);
    }

    $erros = validarBaseImportada($dados);

    if ($erros) {
        erro('A base JSON não é compatível com o formato esperado.', 422, $erros);
    }

    $dadosNormalizados = normalizarBaseImportada($dados);

    $jsonNormalizado = json_encode($dadosNormalizados, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

    if ($jsonNormalizado === false) {
        erro('Não foi possível converter a base enviada para JSON.', 500);
    }

    $salvou = @file_put_contents($destino, $jsonNormalizado, LOCK_EX);

    if ($salvou === false) {
        erro('Não foi possível armazenar a base enviada. Verifique a permissão de escrita da pasta bases/.', 500);
    }

    responder([
        'message' => 'Base adicionada com sucesso.',
        'base' => [
            'id' => $nomeFinal,
            'nome' => $nomeSeguro,
            'arquivo' => $nomeFinal,
            'padrao' => false
        ],
        'registros' => count($dadosNormalizados)
    ], 201);
}

if ($action === 'delete-base') {
    if ($metodo !== 'DELETE') {
        erro('Método não permitido para esta ação.', 405);
    }

    $base = $_GET['base'] ?? '';

    if ($base === '' || $base === 'dados.json') {
        erro('A base padrão não pode ser removida.', 400);
    }

    $nomeSeguro = basename($base);

    if ($nomeSeguro !== $base || strtolower(pathinfo($nomeSeguro, PATHINFO_EXTENSION)) !== 'json') {
        erro('Base de dados inválida.', 400);
    }

    $caminho = $diretorioBases . '/' . $nomeSeguro;

    if (!is_file($caminho)) {
        erro('Base de dados não encontrada.', 404);
    }

    if (!unlink($caminho)) {
        erro('Não foi possível remover a base de dados.', 500);
    }

    responder(['message' => 'Base removida com sucesso.']);
}

$baseSelecionada = $_GET['base'] ?? 'dados.json';
$arquivo = caminhoBaseSelecionada($baseSelecionada, $arquivoPadrao, $diretorioBases);
$usuarios = carregarUsuarios($arquivo);
$id = isset($_GET['id']) ? (int) $_GET['id'] : null;

if ($metodo === 'GET') {
    if ($id !== null) {
        foreach ($usuarios as $usuario) {
            if ((int) $usuario['id'] === $id) {
                responder([
                    'base' => $baseSelecionada,
                    'dados' => $usuario
                ]);
            }
        }

        erro('Usuário não encontrado', 404);
    }

    $resultado = $usuarios;

    if (isset($_GET['Nickname']) && trim($_GET['Nickname']) !== '') {
        $Nickname = textoMinusculo(trim($_GET['Nickname']));

        $resultado = array_filter($resultado, function ($usuario) use ($Nickname) {
            return isset($usuario['Nickname']) && str_contains(textoMinusculo($usuario['Nickname']), $Nickname);
        });
    }

    if (isset($_GET['Titulos']) && trim($_GET['Titulos']) !== '') {
        $Titulos = textoMinusculo(trim($_GET['Titulos']));

        $resultado = array_filter($resultado, function ($usuario) use ($Titulos) {
            return isset($usuario['Titulos']) && str_contains(textoMinusculo($usuario['Titulos']), $Titulos);
        });
    }

    if (isset($_GET['Rating']) && $_GET['Rating'] !== '') {
        $Rating = (float) $_GET['Rating'];

        $resultado = array_filter($resultado, function ($usuario) use ($Rating) {
            return isset($usuario['Rating']) && abs((float) $usuario['Rating'] - $Rating) < 0.00001;
        });
    }

    if (isset($_GET['Team']) && trim($_GET['Team']) !== '') {
        $Team = textoMinusculo(trim($_GET['Team']));

        $resultado = array_filter($resultado, function ($usuario) use ($Team) {
            return isset($usuario['Team']) && str_contains(textoMinusculo($usuario['Team']), $Team);
        });
    }

    $camposOrdenacao = ['id', 'Nickname', 'Titulos', 'Rating', 'Team'];
    $sort = $_GET['sort'] ?? 'id';
    $order = strtolower($_GET['order'] ?? 'asc');

    if (!in_array($sort, $camposOrdenacao, true)) {
        erroValidacao(['sort' => 'Campo de ordenação inválido. Use id, Nickname, Titulos, Rating, Team.']);
    }

    if (!in_array($order, ['asc', 'desc'], true)) {
        erroValidacao(['order' => 'Direção inválida. Use asc ou desc.']);
    }

    usort($resultado, function ($a, $b) use ($sort, $order) {
        $valorA = $a[$sort] ?? null;
        $valorB = $b[$sort] ?? null;

        if (is_string($valorA)) {
            $comparacao = strcasecmp($valorA, (string) $valorB);
        } else {
            $comparacao = $valorA <=> $valorB;
        }

        return $order === 'desc' ? -$comparacao : $comparacao;
    });

    responder([
        'base' => $baseSelecionada,
        'total' => count($resultado),
        'filtros' => [
            'Nickname' => $_GET['Nickname'] ?? null,
            'Titulos' => $_GET['Titulos'] ?? null,
            'Rating' => $_GET['Rating'] ?? null,
            'Team' => $_GET['Team'] ?? null
        ],
        'ordenacao' => [
            'campo' => $sort,
            'direcao' => $order
        ],
        'dados' => array_values($resultado)
    ]);
}

if ($metodo === 'POST') {
    $dados = lerJson();
    $erros = validarUsuario($dados);

    if ($erros) {
        erroValidacao($erros);
    }

    $Nickname = trim($dados['Nickname']);

    if (emailEmUso($usuarios, $Nickname)) {
        erroValidacao(['Nickname' => 'Este Nickname já está cadastrado.']);
    }

    $ids = array_map(function ($usuario) {
        return (int) ($usuario['id'] ?? 0);
    }, $usuarios);
    $novoId = count($ids) > 0 ? max($ids) + 1 : 1;

    $novoUsuario = [
        'id' => $novoId,
        'Nickname' => $Nickname,
        'Titulos' => trim((string) ($dados['Titulos'] ?? '')),
        'Rating' => (float) $dados['Rating'],
        'Team' => trim((string) ($dados['Team'] ?? ''))
    ];

    $usuarios[] = $novoUsuario;
    salvarUsuarios($arquivo, $usuarios);

    responder([
        'base' => $baseSelecionada,
        'dados' => $novoUsuario
    ], 201);
}

if ($metodo === 'PUT') {
    if ($id === null) {
        erro('Informe o ID', 400);
    }

    $dados = lerJson();
    $erros = validarUsuario($dados);

    if ($erros) {
        erroValidacao($erros);
    }

    $Nickname = trim($dados['Nickname']);

    if (emailEmUso($usuarios, $Nickname, $id)) {
        erroValidacao(['Nickname' => 'Este Nickname já está cadastrado.']);
    }

    foreach ($usuarios as $indice => $usuario) {
        if ((int) $usuario['id'] === $id) {
            $usuarios[$indice] = [
                'id' => $id,
                'Nickname' => trim($dados['Nickname']),
                'Titulos' => trim((string) ($dados['Titulos'] ?? '')),
                'Rating' => (float) $dados['Rating'],
                'Team' => trim((string) ($dados['Team'] ?? ''))
            ];

            salvarUsuarios($arquivo, $usuarios);

            responder([
                'base' => $baseSelecionada,
                'dados' => $usuarios[$indice]
            ]);
        }
    }

    erro('Usuário não encontrado', 404);
}

if ($metodo === 'PATCH') {
    if ($id === null) {
        erro('Informe o ID', 400);
    }

    $dados = lerJson();

    if (empty($dados)) {
        erroValidacao(['body' => 'Envie ao menos um campo para atualizar.']);
    }

    $erros = validarUsuario($dados, true);

    if ($erros) {
        erroValidacao($erros);
    }

    if (
        array_key_exists('Nickname', $dados) &&
        emailEmUso($usuarios, trim($dados['Nickname']), $id)
    ) {
        erroValidacao(['Nickname' => 'Este Nickname já está cadastrado.']);
    }

    foreach ($usuarios as $indice => $usuario) {
        if ((int) $usuario['id'] === $id) {
            if (array_key_exists('Nickname', $dados)) {
                $usuarios[$indice]['Nickname'] = trim($dados['Nickname']);
            }

            if (array_key_exists('Titulos', $dados)) {
                $usuarios[$indice]['Titulos'] = trim((string) ($dados['Titulos'] ?? ''));
            }

            if (array_key_exists('Rating', $dados)) {
                $usuarios[$indice]['Rating'] = (float) $dados['Rating'];
            }

            if (array_key_exists('Team', $dados)) {
                $usuarios[$indice]['Team'] = trim((string) ($dados['Team'] ?? ''));
            }

            salvarUsuarios($arquivo, $usuarios);

            responder([
                'base' => $baseSelecionada,
                'dados' => $usuarios[$indice]
            ]);
        }
    }

    erro('Usuário não encontrado', 404);
}

if ($metodo === 'DELETE') {
    if ($id === null) {
        erro('Informe o ID', 400);
    }

    foreach ($usuarios as $indice => $usuario) {
        if ((int) $usuario['id'] === $id) {
            $usuarioExcluido = $usuario;
            array_splice($usuarios, $indice, 1);
            salvarUsuarios($arquivo, $usuarios);

            responder([
                'base' => $baseSelecionada,
                'message' => 'Usuário excluído',
                'dados' => $usuarioExcluido
            ]);
        }
    }

    erro('Usuário não encontrado', 404);
}

erro('Método não permitido', 405);
